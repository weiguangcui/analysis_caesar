from astropy.io import ascii
import matplotlib.pyplot as plt 
from matplotlib import colors as mplcolors
import numpy as np

aa = ascii.read('ssfr_gradients_main_sequence.dat')
x=aa['R']

plt.figure(figsize=(12, 4))

mass_c=[9.0,  9.5, 10.0,  10.5, 11., 11.5]
nmass = len(mass_c)

cmap = plt.cm.get_cmap('jet')  
index=np.linspace(0., 1., nmass)
colors=cmap(index[1:])
colors[2]=mplcolors.to_rgba('y')
nmass=len(mass_c)

plt.subplot(121)
for nn in range(0, nmass-1):
    y=aa['{:.2f}'.format(mass_c[nn])+'-'+'{:.2f}'.format(mass_c[nn+1])+' sSFR']
    y1=aa['{:.2f}'.format(mass_c[nn])+'-'+'{:.2f}'.format(mass_c[nn+1])+' sSFR']+\
        aa['{:.2f}'.format(mass_c[nn])+'-'+'{:.2f}'.format(mass_c[nn+1])+' error sSFR']
    y2=aa['{:.2f}'.format(mass_c[nn])+'-'+'{:.2f}'.format(mass_c[nn+1])+' sSFR']-\
        aa['{:.2f}'.format(mass_c[nn])+'-'+'{:.2f}'.format(mass_c[nn+1])+' error sSFR']

    plt.plot(x,y , color=colors[nn], lw=2., 
             label ='{:.1f}'.format(mass_c[nn])+'-'+'{:.1f}'.format(mass_c[nn+1]))
    plt.xlim(0.,2.)
    plt.ylim(-12.4, -9.45)
    plt.xlabel(r'R [$\rm R_e $]',fontsize=18)
    plt.title('Main sequence',fontsize=18)
    plt.fill_between(x, y1, y2, where=y1 >= y2, 
                     facecolor=colors[nn], alpha=0.4, 
                     edgecolor='none')

plt.subplot(122)
aa = ascii.read('ssfr_gradients_GV.dat')

for nn in range(1, nmass-1):
    y=aa['{:.2f}'.format(mass_c[nn])+'-'+'{:.2f}'.format(mass_c[nn+1])+' sSFR']
    y1=aa['{:.2f}'.format(mass_c[nn])+'-'+'{:.2f}'.format(mass_c[nn+1])+' sSFR']+\
        aa['{:.2f}'.format(mass_c[nn])+'-'+'{:.2f}'.format(mass_c[nn+1])+' error sSFR']
    y2=aa['{:.2f}'.format(mass_c[nn])+'-'+'{:.2f}'.format(mass_c[nn+1])+' sSFR']-\
        aa['{:.2f}'.format(mass_c[nn])+'-'+'{:.2f}'.format(mass_c[nn+1])+' error sSFR']

    plt.plot(x,y , color=colors[nn], lw=2., 
             label ='{:.1f}'.format(mass_c[nn])+'-'+'{:.1f}'.format(mass_c[nn+1]))
    plt.xlim(0.,2.)
    plt.ylim(-12.4, -9.45)
    plt.xlabel(r'R [$\rm R_e $]',fontsize=18)
    plt.title('GV',fontsize=18)
    plt.fill_between(x, y1, y2, where=y1 >= y2, 
                     facecolor=colors[nn], alpha=0.4, 
                     edgecolor='none')

plt.show()
plt.savefig('test.png')